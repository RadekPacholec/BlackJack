class GameOverException(Exception):
	pass


class GameOverUserException(Exception):
	pass


class GameOverCroupierException(Exception):
	pass
